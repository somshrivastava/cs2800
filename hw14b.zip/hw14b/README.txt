How to Run This Assignment
1. Open VS Code
2. Ensure you have Java and Maven installed
3. Open this folder as a Maven project
4. Run `mvn test`

Dependencies:
JUnit 4 and JUnit-QuickCheck
Jackson Databind
